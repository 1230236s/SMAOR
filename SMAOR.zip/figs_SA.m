figure(1)
plot(t,e(1,:),'-.m')
hold on
plot(t,e(2,:),'c')
legend({'$\nabla {{ T}_{6m}}(t)$','$\nabla {{ T}_{6n}}(t)$'},'Interpreter','latex')
hold on
xlabel('Time(s)'),
ylabel('{The regulated total temperature increment at the outlet of the low-pressure turbine}')



figure (2)
plot(t,u(1,:),'g')
legend({'$\nabla {W_{fm}}(t)$'},'Interpreter','latex')
xlabel('Time (s)'),
ylabel('The increment in main combustor fuel flow')

figure (3)
plot(t,d(:,1),'--m')
xlabel('Time (s)'),
ylabel('The unknown external interference input')

figure(4)
plot(t,x(1,:),'--r')
hold on
plot(t,x(2,:),'b')
hold on
legend({'$\nabla {{ N}_L}(t)$','$\nabla {{ N}_H}(t)$'},'Interpreter','latex')
xlabel('Time(s)'),
ylabel('{The rotational speeds increment of the low-pressure shaft and high-pressure shaft}')

% 
 figure (5)
 plot(t,sig(:,1),'r')
 legend({'$\gamma (t)$'},'Interpreter','latex')
 xlabel('Time (s)'),
 ylabel('The switching signals')
%  legend('\delta (t)')



 figure (6) 
 plot(t,s(1,:),'r')
 hold on
 legend('s(t)')
 xlabel('Time (s)'),
 ylabel('The switched fuzzy integral sliding surface')
 
% 
% figure (6)
% plot(t,w(:,1),'m')
% hold on
% plot(t,w(:,2),'-.b')
% legend('$\varphi (t)$')
% hold on
% xlabel('Time (s)'),
% ylabel('The external disturbance input')



% figure(7)
% plot(t,e9(1,:),'-.r')
% hold on
% plot(t,e9(2,:),'g')
% legend({'$\nabla {{ T}_{6m}}(t)$','$\nabla {{ T}_{6n}}(t)$'},'Interpreter','latex')
% hold on
% xlabel('Time(s)'),
% ylabel(' The unregulated total temperature increment at the outlet of the low-pressure turbine');



