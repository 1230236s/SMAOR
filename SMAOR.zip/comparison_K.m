
M1=[-3.7401 1.4001;0.4752 -4.5586];
M22=[-2.9378 1.0937;0.4149 -3.4793];
% N1=[231.5508;657.3084];
% N22=[239.7745;688.5648];
N1=[-5;1];
N22=[-5;1];
A1=[-0.0620 -0.3214;0.0523 0.1851];
A22=[-0.0572 -0.3081;0.0399 0.1401];
B1=[0.1;0.5];
B2=[0.5;0.1];
S1=[0 1;-0.5 0];
S2=[0 1;-0.8 0];
pa1=[1 -1;1 1];
pa2=[1 0.5;-0.5 1];
r=1.5;
miu=1.2;
iota=0.1;
iota2=2;
% 2st rule
% definite subsystem1's subsystem2's constant
M11=[-2.9150 1.0362;0.7871 -3.4432];
M2=[-1.7435 0.7462;0.5080 -2.1737];
% N11=[239.3185;723.6188];
% N2=[287.6845;891.1333];
N11=[-5;1];
N2=[-5;1];
A11=[0.0496 -0.3524;0.0089 0.1395];
A2=[0.0244 -0.2665;0.0017 0.0855];
B11=[0.1;0.5];
B22=[0.5;0.1];
S11=[0 1;-0.5 0];
S22=[0 1;-1 0];

C1=[0.3;0];
C2=[0;0.1];
C11=[0.3;0];
C22=[0;0.1];

V1=[0;0.1];
V2=[0;0.1];
V11=[0;0.1];
V22=[0;0.1];
% matrix produced by the transformation of different coordinates
T12=[-1 0;-1 2];

%%%%%
D1=pa1*S1-M1*pa1;
D2=pa2*S2-M2*pa2;
D11=pa1*S11-M11*pa1;
D22=pa2*S22-M22*pa2;
F1=-A1*pa1;
F2=A2*pa2;
F11=A11*pa1;
F22=A22*pa2;





setlmis([])
W1=lmivar(1,[2 1]);
W2=lmivar(1,[2 1]);
L1=lmivar(2,[1 2]);
L2=lmivar(2,[1 2]);
L11=lmivar(2,[1 2]);
L22=lmivar(2,[1 2]);
% V1=lmivar(2,[2,1]);
% V2=lmivar(2,[2,1]);
% V11=lmivar(2,[2,1]);
% V22=lmivar(2,[2,1]);
% C1=lmivar(2,[2 1]);
% C2=lmivar(2,[2 1]);
% C11=lmivar(2,[2 1]);
% C22=lmivar(2,[2 1]);
k=lmivar(1,[1 1]);

%描述矩阵不等�?
% rule 1 subsystem 1
lmiterm([1 1 1 	W1],M1,1,'s')
lmiterm([1 1 1 	L1],N1,1,'s')
lmiterm([1 1 1 	W1],r,1)
lmiterm([1 1 1 	0],iota)


lmiterm([1 1 2 W1],1,A1'*B1)

lmiterm([1 1 3 0],0)

lmiterm([1 1 4 0],0)

lmiterm([1 1 5 0],0)

lmiterm([1 1 6 W1],1,A1')

lmiterm([1 1 7 W1],1,1)

lmiterm([1 2 2 k],-1,1)

lmiterm([1 2 3 0],B1')

lmiterm([1 2 4 0],C1')
lmiterm([1 2 4 0],-(V1')*(pa1'))

lmiterm([1 2 5 0],0)

lmiterm([1 2 6 0],0)

lmiterm([1 2 7 0],0)

lmiterm([1 3 3 0],-1)
 
lmiterm([1 3 4 0],0)

lmiterm([1 3 5 0],0)

lmiterm([1 3 6 0],0)

lmiterm([1 3 7 0],0)

lmiterm([1 4 4 0],-iota)

lmiterm([1 4 5 0],0)

lmiterm([1 4 6 0],0)

lmiterm([1 4 7 0],0)

lmiterm([1 5 5 0],-iota2)

lmiterm([1 5 6 0],0)

lmiterm([1 5 7 0],0)

lmiterm([1 6 6 0],-1)

lmiterm([1 6 7 0],0)

lmiterm([1 7 7 0],-4/(iota2))



% rule 1 subsysrem'2
lmiterm([2 1 1 	W2],M2,1,'s')
lmiterm([2 1 1 	L2],N2,1,'s')
lmiterm([2 1 1 	W2],r,1)
lmiterm([2 1 1 	0],iota)


lmiterm([2 1 2 W2],1,A2'*B2)

lmiterm([2 1 3 0],0)

lmiterm([2 1 4 0],0)

lmiterm([2 1 5 0],0)

lmiterm([2 1 6 W2],1,A2')

lmiterm([2 1 7 W2],1,1)

lmiterm([2 2 2 k],-1,1)

lmiterm([2 2 3 0],B2')

lmiterm([2 2 4 0],C2')
lmiterm([2 2 4 0],-(V2')*(pa2'))

lmiterm([2 2 5 0],0)

lmiterm([2 2 6 0],0)

lmiterm([2 2 7 0],0)

lmiterm([2 3 3 0],-1)
 
lmiterm([2 3 4 0],0)

lmiterm([2 3 5 0],0)

lmiterm([2 3 6 0],0)

lmiterm([2 3 7 0],0)

lmiterm([2 4 4 0],-iota)

lmiterm([2 4 5 0],0)

lmiterm([2 4 6 0],0)

lmiterm([2 4 7 0],0)

lmiterm([2 5 5 0],-iota2)

lmiterm([2 5 6 0],0)

lmiterm([2 5 7 0],0)

lmiterm([2 6 6 0],-1)

lmiterm([2 6 7 0],0)

lmiterm([2 7 7 0],-4/(iota2))



% rule 2 subsystem'1
lmiterm([3 1 1 	W1],M11,1,'s')
lmiterm([3 1 1 	L11],N11,1,'s')
lmiterm([3 1 1 	W1],r,1)
lmiterm([3 1 1 	0],iota)


lmiterm([3 1 2 W1],1,A11'*B11)

lmiterm([3 1 3 0],0)

lmiterm([3 1 4 0],0)

lmiterm([3 1 5 0],0)

lmiterm([3 1 6 W1],1,A11')

lmiterm([3 1 7 W1],1,1)

lmiterm([3 2 2 k],-1,1)

lmiterm([3 2 3 0],B11')

lmiterm([3 2 4 0],C11')
lmiterm([3 2 4 0],-(V11')*(pa1'))

lmiterm([3 2 5 0],0)

lmiterm([3 2 6 0],0)

lmiterm([3 2 7 0],0)

lmiterm([3 3 3 0],-1)
 
lmiterm([3 3 4 0],0)

lmiterm([3 3 5 0],0)

lmiterm([3 3 6 0],0)

lmiterm([3 3 7 0],0)

lmiterm([3 4 4 0],-iota)

lmiterm([3 4 5 0],0)

lmiterm([3 4 6 0],0)

lmiterm([3 4 7 0],0)

lmiterm([3 5 5 0],-iota2)

lmiterm([3 5 6 0],0)

lmiterm([3 5 7 0],0)

lmiterm([3 6 6 0],-1)

lmiterm([3 6 7 0],0)

lmiterm([3 7 7 0],-4/(iota2))

% rule 2 subsystem'2
lmiterm([4 1 1 	W2],M22,1,'s')
lmiterm([4 1 1 	L22],N22,1,'s')
lmiterm([4 1 1 	W2],r,1)
lmiterm([4 1 1 	0],iota)


lmiterm([4 1 2 W2],1,A22'*B22)

lmiterm([4 1 3 0],0)

lmiterm([4 1 4 0],0)

lmiterm([4 1 5 0],0)

lmiterm([4 1 6 W2],1,A22')

lmiterm([4 1 7 W2],1,1)

lmiterm([4 2 2 k],-1,1)

lmiterm([4 2 3 0],B22')

lmiterm([4 2 4 0],C22')
lmiterm([4 2 4 0],-(V22')*(pa2'))

lmiterm([4 2 5 0],0)

lmiterm([4 2 6 0],0)

lmiterm([4 2 7 0],0)

lmiterm([4 3 3 0],-1)
 
lmiterm([4 3 4 0],0)

lmiterm([4 3 5 0],0)

lmiterm([4 3 6 0],0)

lmiterm([4 3 7 0],0)

lmiterm([4 4 4 0],-iota)

lmiterm([4 4 5 0],0)

lmiterm([4 4 6 0],0)

lmiterm([4 4 7 0],0)

lmiterm([4 5 5 0],-iota2)

lmiterm([4 5 6 0],0)

lmiterm([4 5 7 0],0)

lmiterm([4 6 6 0],-1)

lmiterm([4 6 7 0],0)

lmiterm([4 7 7 0],-4/(iota2))




%正定矩阵的限�?
lmiterm([5 1 1 W1],-1,1)
lmiterm([6 1 1 W2],-1,1)
lmiterm([7 1 1 k],-1,1)

%限制Vj<qVi
lmiterm([11 1 1 W1],-miu,1)
lmiterm([11 1 2 W1],1,T12)


lmiterm([11 2 2 W2],-1,1)

%%%
lmis=getlmis;
[tmin, xfeas]=feasp(lmis);
%将变量转换为矩阵
aW1=dec2mat(lmis,xfeas,W1);
aW2=dec2mat(lmis,xfeas,W2);
aL1=dec2mat(lmis,xfeas,L1);
aL2=dec2mat(lmis,xfeas,L2);
aL11=dec2mat(lmis,xfeas,L11);
aL22=dec2mat(lmis,xfeas,L22);
% aV1=dec2mat(lmis,xfeas,V1);
% aV2=dec2mat(lmis,xfeas,V2);
% aV11=dec2mat(lmis,xfeas,V11);
% aV22=dec2mat(lmis,xfeas,V22);
% aC1=dec2mat(lmis,xfeas,C1);
% aC2=dec2mat(lmis,xfeas,C2);
% aC11=dec2mat(lmis,xfeas,C11);
% aC22=dec2mat(lmis,xfeas,C22);
ak=dec2mat(lmis,xfeas,k);


%%%控制器增�?
K1=aL1*inv(aW1);
K2=aL2*inv(aW2);
K11=aL11*inv(aW1);
K22=aL22*inv(aW2);
% %%% augment system
% %
AA1=M1+N1*K1;
eig(AA1)

AA2=M2+N2*K2;
eig(AA2)

AA11=M11+N11*K11;
eig(AA11)

AA22=M22+N22*K22;
eig(AA22)

H1=C1-pa1*V1;
H2=C2-pa2*V2;
H11=C1-pa1*V11;
H22=C22-pa2*V22;